# ac/dc
update LikesMusic SET artist_id = 606 where artist_id = 29 or artist_id = 133 or artist_id = 225;

# alt J
update LikesMusic SET artist_id = 424 where artist_id = 462

# angra
update LikesMusic SET artist_id = 314 where artist_id = 134;

# arctic monkeys
update LikesMusic SET artist_id = 9 where artist_id = 425;

# coldplay
update LikesMusic SET artist_id = 92 where artist_id = 227;

# foo fighters
update LikesMusic SET artist_id = 94 where artist_id = 156;

# franz ferdinand
update LikesMusic SET artist_id = 484 where artist_id = 145;

# guns n' roses
update LikesMusic SET artist_id = 617 where artist_id = 441 or artist_id = 65;

# kiss
update LikesMusic SET artist_id = 100 where artist_id = 227;

# led zeppelin
update LikesMusic SET artist_id = 101 where artist_id = 608;

# legião urbana
update LikesMusic SET artist_id = 102 where artist_id = 206;

# lynyrd skynyrd
update LikesMusic SET artist_id = 186 where artist_id = 384;

# megadeth
update LikesMusic SET artist_id = 418 where artist_id = 609;

# metallica
update LikesMusic SET artist_id = 33 where artist_id = 282;

# muse 
update LikesMusic SET artist_id = 12 where artist_id = 448;

# ozzy osbourne
update LikesMusic SET artist_id = 110 where artist_id = 284;

# queen 
update LikesMusic SET artist_id = 6 where artist_id = 151 or artist_id = 240;

# rage against the machine
update LikesMusic SET artist_id = 114 where artist_id = 221;

# red hot chili peppers
update LikesMusic SET artist_id = 57 where artist_id = 337;

# scorpions
update LikesMusic SET artist_id = 117 where artist_id = 348 or artist_id = 625;

# system of a down
update LikesMusic SET artist_id = 419 where artist_id = 602;

# the beatles
update LikesMusic SET artist_id = 8 where artist_id = 137;

# the white stripes
update LikesMusic SET artist_id = 124 where artist_id = 542;

# tiesto
update LikesMusic SET artist_id = 164 where artist_id = 404;

# titãs
update LikesMusic SET artist_id = 127 where artist_id = 214;

# tom jobim
update LikesMusic SET artist_id = 241 where artist_id = 349

# é o tchan
update LikesMusic SET artist_id = 241 where artist_id = 349







