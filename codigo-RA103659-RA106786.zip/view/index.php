<html>
	<head>
		<title> MC536 SocialNET</title>
	</head>
	<body>
		<h1> MC536 SocialNET</h1>
		<h2><a href="./person_new.php">Novo usu&aacute;rio</a></h2>
		<h2><a href="./person_list.php">Listar usu&aacute;rios</a></h2>
		<h2><a href="./artist_list.php">Listar artistas</a></h2>
		<h2><a href="./statistics.php">Estat&iacute;sticas</a></h2>
	</body>
</html>
