<h1 class="cover-heading">Bem vindo!</h1>
<p class="lead">Este projeto foi desenvolvido para a avalia&ccedil;&atilde;o do curso de MC536 do primeiro semestre de 2014</p>
	<p class="lead">
		<a href="?page=person_new">Novo usu&aacute;rio</a>
	</p>
	<p class="lead">
		<a href="?page=person_list">Listar usu&aacute;rios</a>
	</p>
	<p class="lead">
		<a href="?page=artist_list">Listar artistas</a>
	</p>
	<p class="lead">
		<a href="./statistics.php">Estat&iacute;sticas</a>
	</p>
</p>
